require "pagy/extras/bootstrap" # If you're using Bootstrap
Pagy::DEFAULT[:items] = 20      # Number of items per page
